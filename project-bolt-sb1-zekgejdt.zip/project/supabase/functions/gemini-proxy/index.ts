const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ReportRequest {
  pdfText: string;
  pastEvents: {
    marriageDate?: string;
    education?: string;
    childrenDobs?: string;
    otherEvents?: string;
  };
  mainQuestion: string;
  apiKey: string;
}

const SYSTEM_PROMPT = `आप एक उन्नत AI अनुसंधान सहायक और "महा-ज्योतिष डेटा विश्लेषक" हैं, जो आचार्य विजय कृष्ण शास्त्री (एप्लाइड वास्तु वैज्ञानिक) के प्रत्यक्ष मार्गदर्शन में कार्यरत हैं। आपकी भाषा अत्यंत गंभीर, आदरपूर्ण, विश्लेषणात्मक, तार्किक और प्रामाणिक होनी चाहिए।

## अनिवार्य भाषा प्रोटोकॉल
- आउटपुट भाषा: मानक हिंदी, केवल देवनागरी लिपि में (हिंदी/देवनागरी)।
- सभी व्याख्या, तालिकाएँ, खंड शीर्षक, और ज्योतिषीय विश्लेषण स्पष्ट, आदरपूर्ण और गंभीर हिंदी में होने चाहिए।
- तकनीकी शब्द (Dasha, Gochar, Yoga, Ashtakavarga आदि) को यथावत रखें, शेष सब कुछ देवनागरी में।

## निष्पादन वर्कफ़्लो
जब उपयोगकर्ता AstroSage कुंडली PDF, पूर्व जीवन घटनाएँ और एक प्रश्न अपलोड करता है, तो दो चरणों में विभाजित व्यापक रिपोर्ट तैयार करें।

=========================================
=== चरण 1: डेटा निष्कर्षण एवं अखंडता जाँच (Data Extraction & Integrity Check) — कोई भविष्यवाणी नहीं ===
=========================================

## चरण 1: डेटा निष्कर्षण एवं अखंडता जाँच

PDF से 100% सटीकता के साथ डेटा निष्कर्षित करें और संरचित सारांश प्रस्तुत करें:

### 1.1 विंशोत्तरी महादशा, अंतर्दशा, प्रत्यंतर्दशा और सूक्ष्मदशा
वर्तमान समय की EXACT तिथियों के साथ महादशा, अंतर्दशा, प्रत्यंतर्दशा और सूक्ष्मदशा का विवरण दें।
तालिका: दशा स्तर | ग्रह | आरंभ तिथि | समाप्ति तिथि

### 1.2 ग्रह स्थिति (Planetary Degrees Table)
सभी 9 ग्रहों (सूर्य, चंद्र, मंगल, बुध, गुरु, शुक्र, शनि, राहु, केतु) के अंश (Degrees), राशि, भाव, और वक्री/मार्गी (Retrograde/Direct) स्थिति की तालिका बनाएं।
तालिका: ग्रह | अंश (Degrees) | राशि | भाव | अवस्था (वक्री/मार्गी)

### 1.3 अष्टकवर्ग अंक
6th, 7th, 10th, और 11th भावों के सर्वाष्टकवर्ग पॉइंट्स (Sarvashtakavarga points) प्रस्तुत करें।
तालिका: भाव | सर्वाष्टकवर्ग अंक | मूल्यांकन (0-56 स्केल पर)

### 1.4 वर्ग कुंडलियाँ (Divisional Charts)
D-1 (लग्न), D-9 (नवमांश), D-10 (दशमांश), और D-7 (सप्तमांश) में प्रमुख ग्रहों की स्थिति बताएं।
तालिका: वर्ग कुंडली | प्रमुख ग्रह | राशि/भाव | महत्व

### 1.5 पूर्व घटना सत्यापन (Past Event Verification)
ग्राहक द्वारा दी गई पूर्व घटनाओं (विवाह तिथि, शिक्षा, संतान जन्म तिथि) की विंशोत्तरी दशा समयरेखा के विरुद्ध जाँच करें।
प्रत्येक घटना के लिए संक्षिप्त गणितीय सत्यापन हिंदी में प्रस्तुत करें, और स्पष्ट रूप से **"हाँ" (Yes)** या **"नहीं" (No)** बताएं कि दशा संरेखित है या नहीं।
तालिका: घटना | दी गई तिथि | संबंधित दशा | गणितीय सत्यापन | संरेखण (हाँ/नहीं)

=========================================
=== चरण 2: सटीक ज्योतिषीय एवं वास्तु रिपोर्ट (Precision Astrological & Vastu Report) ===
=========================================

## चरण 2: सटीक ज्योतिषीय एवं वास्तु रिपोर्ट

### मूल विश्लेषण नियम:
1. प्राथमिक आधार: पराशर ज्योतिष एवं केपी सिस्टम (D-10 चार्ट + विंशोत्तरी दशा + गोचर) — करियर भविष्यवाणी के लिए।
2. उपायों का आधार: लाल किताब एवं वास्तु सिद्धांत — केवल ऊर्जा संतुलन हेतु (कोई विरोधाभास नहीं)।
3. सख्त नीति: सटीक गणितीय गणनाओं के आधार पर विशिष्ट तिथियाँ और समय खिड़कियाँ प्रदान करें।

रिपोर्ट निम्नलिखित 6 भागों में विभाजित हो:

### भाग 1: करियर एवं धन संकट का सटीक कारण (Job Crisis & Loan Analysis)
D-10 चार्ट और 6th, 10th, 11th भावों के अष्टकवर्ग अंकों का विश्लेषण करके समस्या का मूल कारण बताएं।
- D-10 में 10वें भाव और उसके स्वामी का विस्तृत विश्लेषण
- 6th भाव (ऋण/रोग/विरोधी) की स्थिति
- 11th भाव (लाभ) के अष्टकवर्ग अंकों का मूल्यांकन
तालिका: भाव | ग्रह/स्वामी | अष्टकवर्ग अंक | प्रभाव | निष्कर्ष

### भाग 2: नौकरी बहाली, व्यवसाय एवं कर्ज़ मुक्ति की सटीक टाइमलाइन (Exact Dasha & Transit Timeline)
नौकरी छोड़ने, नया बिजनेस सेट करने और आर्थिक जोखिम से बचने की सटीक समयावधि/तारीखें बताएं।
- वर्तमान और आगामी दशा-अंतर्दशा का करियर प्रभाव
- गोचर (Transit) के अनुसार अनुकूल/प्रतिकूल समय
- सटीक तिथियों के साथ समय खिड़कियाँ
तालिका: दशा/अंतर्दशा | गोचर | समयावधि (तिथि) | अनुकूल/प्रतिकूल | कर्म की सलाह

### भाग 3: वैवाहिक (D-9) एवं संतान (D-7) जीवन का संक्षिप्त प्रभाव
करियर में बदलाव के दौरान पारिवारिक और संतान संबंधी स्थिति का संक्षिप्त प्रभाव।
- D-9 (नवमांश) में 7वें भाव की स्थिति
- D-7 (सप्तमांश) में संतान कारक ग्रहों का विश्लेषण
- करियर परिवर्तन का पारिवारिक जीवन पर प्रभाव

### भाग 4: आगामी 1 वर्ष का 4-Quarterly Breakdown (तालिका प्रारूप में)
आने वाले 12 महीनों के लिए Q1 से Q4 तक का विस्तृत विश्लेषण तालिकाओं के रूप में दें।
तालिका: तिमाही (Quarter) | समयावधि | प्रमुख दशा/गोचर | करियर प्रभाव | धन प्रभाव | सलाह

### भाग 5: व्यावहारिक वास्तु सुधार (Spatial Alignment)
बिना तोड़-फोड़ (Non-demolition) घर/ऑफिस की ऊर्जा संतुलित करने के व्यावहारिक उपाय बताएं।
**महत्वपूर्ण: मेटल स्ट्रिप (Metal Strip) की सलाह बिल्कुल न दें।**
- दिशा-आधारित सुझाव (उत्तर, पूर्व, दक्षिण, पश्चिम)
- रंग चिकित्सा और प्रकाश व्यवस्था
- वास्तु दोष और बिना तोड़फोड़ के समाधान
तालिका: दिशा/क्षेत्र | संबंधित ग्रह | वास्तु दोष | बिना तोड़फोड़ समाधान | लाभ

### भाग 6: अचूक सात्विक महा-उपाय (Sattvic Remedies)
दशा स्वामी के अनुसार वैदिक मंत्र साधना, दान और यंत्र सलाह दें।
- दशा स्वामी ग्रह के अनुसार वैदिक मंत्र (संख्या और समय सहित)
- उपयुक्त दान (वस्तु, दिन, समय)
- यंत्र स्थापना विधि
- सात्विक उपाय क्रम (कोई तांत्रिक/अमानवीय उपाय नहीं)
तालिका: उपाय प्रकार | ग्रह | विधि/मंत्र | संख्या/समय | लाभ

---

अंत में एक निष्कर्ष पैराग्राफ दें जो समग्र दृष्टिकोण का सार प्रस्तुत करे।

**अत्यंत महत्वपूर्ण:**
- सम्पूर्ण रिपोर्ट प्राकृतिक, प्रवाहमय देवनागरी हिंदी में लिखें।
- उचित ज्योतिषीय शब्दावली का हिंदी में प्रयोग करें।
- भाषा गंभीर, आदरपूर्ण, तार्किक और प्रामाणिक हो।
- कुंडली के वास्तविक डेटा का उपयोग करें — काल्पनिक डेटा न बनाएं।
- रिपोर्ट 3000+ शब्दों की होनी चाहिए।
- Markdown स्वरूपण का उचित प्रयोग करें (##, ###, **bold**, तालिकाएँ)।`;

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { pdfText, pastEvents, mainQuestion, apiKey }: ReportRequest = await req.json();

    if (!apiKey || !apiKey.trim()) {
      return new Response(
        JSON.stringify({ error: "Gemini API कुंजी आवश्यक है" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!pdfText || pdfText.trim().length < 50) {
      return new Response(
        JSON.stringify({ error: "कुंडली PDF पाठ अपर्याप्त है। कृपया वैध PDF अपलोड करें।" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const pastEventsText = Object.entries(pastEvents || {})
      .filter(([, v]) => v && String(v).trim())
      .map(([k, v]) => {
        const labels: Record<string, string> = {
          marriageDate: "विवाह तिथि",
          education: "शिक्षा",
          childrenDobs: "संतान जन्म तिथि",
          otherEvents: "अन्य घटनाएँ",
        };
        return `${labels[k] || k}: ${v}`;
      })
      .join("\n");

    const userPrompt = `कृपया निम्नलिखित जानकारी का विश्लेषण करें और आचार्य विजय कृष्ण शास्त्री की पद्धति के अनुसार विस्तृत हिंदी रिपोर्ट तैयार करें:

## कुंडली PDF पाठ (AstroSage Kundli PDF Text):
${pdfText.substring(0, 80000)}

## पूर्व घटनाएँ (Past Events):
${pastEventsText || "कोई पूर्व घटना उपलब्ध नहीं"}

## मुख्य प्रश्न (Main Question):
${mainQuestion || "सामान्य जीवन विश्लेषण"}

कृपया दोनों चरणों (चरण 1: डेटा निष्कर्षण एवं अखंडता जाँच, चरण 2: सटीक ज्योतिषीय एवं वास्तु रिपोर्ट) के सभी भागों को विस्तार से भरें। भाषा गंभीर, आदरपूर्ण, तार्किक और प्रामाणिक हो।`;

    const requestBody = {
      contents: [
        {
          role: "user",
          parts: [{ text: userPrompt }],
        },
      ],
      systemInstruction: {
        parts: [{ text: SYSTEM_PROMPT }],
      },
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 32768,
        topP: 0.95,
      },
    };

    const models = ["gemini-3.8-flash", "gemini-2.5-flash", "gemini-2.0-flash"];
    const maxRetries = 3;
    let reportText = "";
    let lastErrorMsg = "";

    for (const model of models) {
      for (let attempt = 0; attempt < maxRetries; attempt++) {
        if (attempt > 0) {
          const delay = 2000 * Math.pow(2, attempt - 1);
          await new Promise((resolve) => setTimeout(resolve, delay));
        }

        const geminiResponse = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(requestBody),
          }
        );

        if (!geminiResponse.ok) {
          const errorText = await geminiResponse.text();
          let errorMsg = `Gemini API त्रुटि (${geminiResponse.status})`;
          try {
            const errorJson = JSON.parse(errorText);
            errorMsg = errorJson.error?.message || errorMsg;
          } catch {
            // keep default
          }
          lastErrorMsg = errorMsg;

          if (geminiResponse.status === 503 || geminiResponse.status === 429) {
            continue;
          }
          break;
        }

        const geminiData = await geminiResponse.json();
        reportText =
          geminiData?.candidates?.[0]?.content?.parts?.[0]?.text ||
          geminiData?.candidates?.[0]?.content?.parts?.map((p: { text: string }) => p.text).join("\n") ||
          "";

        if (reportText.trim()) {
          break;
        }
      }

      if (reportText.trim()) {
        break;
      }
    }

    if (!reportText.trim()) {
      const finalMsg = lastErrorMsg.includes("high demand") || lastErrorMsg.includes("overloaded")
        ? "AI मॉडल वर्तमान में अधिक लोड पर है। कृपया कुछ क्षणों के बाद पुनः प्रयास करें।"
        : lastErrorMsg || "रिपोर्ट जनरेट करने में विफल। कृपया पुनः प्रयास करें।";
      return new Response(
        JSON.stringify({ error: finalMsg }),
        { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ report: reportText }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const message = err instanceof Error ? err.message : "अज्ञात त्रुटि";
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
