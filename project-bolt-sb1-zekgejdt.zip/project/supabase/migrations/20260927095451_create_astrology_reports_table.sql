/*
# Create astrology_reports table (single-tenant, no auth)

1. New Tables
- `astrology_reports`
  - `id` (uuid, primary key)
  - `client_name` (text, name of the client)
  - `pdf_filename` (text, name of uploaded PDF)
  - `pdf_text` (text, extracted text from PDF)
  - `past_events` (jsonb, structured past event data: marriage date, education, children DOBs)
  - `main_question` (text, the client's main question)
  - `report_markdown` (text, the generated Hindi markdown report)
  - `status` (text, pending/generating/completed/failed)
  - `created_at` (timestamptz)

2. Security
- Enable RLS on `astrology_reports`.
- Allow anon + authenticated CRUD since this is a single-tenant app with no sign-in.
*/

CREATE TABLE IF NOT EXISTS astrology_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text,
  pdf_filename text,
  pdf_text text,
  past_events jsonb,
  main_question text,
  report_markdown text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE astrology_reports ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_reports" ON astrology_reports;
CREATE POLICY "anon_select_reports" ON astrology_reports FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reports" ON astrology_reports;
CREATE POLICY "anon_insert_reports" ON astrology_reports FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_reports" ON astrology_reports;
CREATE POLICY "anon_update_reports" ON astrology_reports FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_reports" ON astrology_reports;
CREATE POLICY "anon_delete_reports" ON astrology_reports FOR DELETE
TO anon, authenticated USING (true);
