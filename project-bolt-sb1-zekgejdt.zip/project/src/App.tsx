import { useState } from "react";
import {
  Sparkles,
  FileText,
  CalendarHeart,
  KeyRound,
  Loader2,
  AlertCircle,
  Moon,
  Star,
  HelpCircle,
} from "lucide-react";
import Sidebar from "@/components/Sidebar";
import PdfUpload from "@/components/PdfUpload";
import PastEventsForm from "@/components/PastEventsForm";
import ApiKeyInput from "@/components/ApiKeyInput";
import GenerateButton from "@/components/GenerateButton";
import ReportRenderer from "@/components/ReportRenderer";
import { supabase } from "@/lib/supabase";
import type { PastEvents } from "@/lib/types";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

export default function App() {
  const [clientName, setClientName] = useState("");
  const [pdfText, setPdfText] = useState("");
  const [pdfFilename, setPdfFilename] = useState("");
  const [pageCount, setPageCount] = useState(0);
  const [pastEvents, setPastEvents] = useState<PastEvents>({
    marriageDate: "",
    education: "",
    childrenDobs: "",
    otherEvents: "",
  });
  const [mainQuestion, setMainQuestion] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [report, setReport] = useState("");

  const canGenerate = pdfText.trim().length > 50 && apiKey.trim().length > 10;

  const handleGenerate = async () => {
    setError(null);
    setReport("");
    setLoading(true);

    try {
      const { data: recordData } = await supabase
        .from("astrology_reports")
        .insert({
          client_name: clientName || null,
          pdf_filename: pdfFilename || null,
          pdf_text: pdfText.substring(0, 50000),
          past_events: pastEvents,
          main_question: mainQuestion || null,
          status: "generating",
        })
        .select("id")
        .maybeSingle();

      const recordId = recordData?.id;

      const response = await fetch(`${SUPABASE_URL}/functions/v1/gemini-proxy`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          pdfText,
          pastEvents,
          mainQuestion,
          apiKey,
        }),
      });

      if (!response.ok) {
        const errBody = await response.json().catch(() => ({}));
        throw new Error(errBody.error || `सर्वर त्रुटि (${response.status})`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      if (!data.report || !data.report.trim()) {
        throw new Error("रिपोर्ट खाली है। कृपया पुनः प्रयास करें।");
      }

      setReport(data.report);

      if (recordId) {
        await supabase
          .from("astrology_reports")
          .update({ report_markdown: data.report, status: "completed" })
          .eq("id", recordId);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "अज्ञात त्रुटि";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setReport("");
    setError(null);
    setPdfText("");
    setPdfFilename("");
    setPageCount(0);
    setClientName("");
    setMainQuestion("");
    setPastEvents({
      marriageDate: "",
      education: "",
      childrenDobs: "",
      otherEvents: "",
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      <Sidebar />

      <div className="flex-1 min-w-0">
        {/* Top Bar */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-10 no-print">
          <div className="px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="lg:hidden w-10 h-10 rounded-lg bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-slate-900 font-bold text-xl">Acharya Vijay Krishna Shastri विश्लेषण डैशबोर्ड</h1>
                <p className="text-slate-400 text-xs hidden sm:block">
                  AI-संचालित कुंडली विश्लेषण · Devanagari Hindi रिपोर्ट
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-lg">
                <Moon className="w-4 h-4 text-amber-500" />
                <span className="text-xs text-slate-600 font-medium">Acharya Vijay Krishna Shastri AI</span>
              </div>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center text-white font-bold text-sm">
                ज
              </div>
            </div>
          </div>
        </header>

        <main className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto">
          {/* Info Banner */}
          {!report && !loading && (
            <div className="mb-6 bg-gradient-to-r from-slate-900 to-slate-800 rounded-2xl p-6 md:p-8 text-white overflow-hidden relative no-print">
              <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
              <div className="relative">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-amber-400" />
                  <span className="text-amber-400 text-xs font-semibold uppercase tracking-wider">
                    वैदिक ज्योतिष · वास्तु शास्त्र
                  </span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-2">
                  अपनी कुंडली का संपूर्ण विश्लेषण प्राप्त करें
                </h2>
                <p className="text-slate-300 text-sm md:text-base max-w-2xl">
                  AstroSage कुंडली PDF अपलोड करें, पूर्व घटनाएँ दर्ज करें, और AI द्वारा तैयार
                  विस्तृत देवनागरी हिंदी रिपोर्ट प्राप्त करें — दो चरणों में: डेटा निष्कर्षण एवं
                  अखंडता जाँच, तत्पश्चात सटीक ज्योतिषीय-वास्तु विश्लेषण।
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3 no-print">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-red-800 font-medium text-sm">त्रुटि</p>
                <p className="text-red-600 text-sm mt-0.5">{error}</p>
              </div>
              <button
                onClick={() => setError(null)}
                className="text-red-400 hover:text-red-600 text-sm font-medium"
              >
                बंद करें
              </button>
            </div>
          )}

          <div className={`${report || loading ? "hidden" : "block"} space-y-6 no-print`}>
            {/* Section 1: PDF Upload */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">1. कुंडली PDF अपलोड</h3>
                  <p className="text-slate-400 text-xs">AstroSage कुंडली PDF (~56 पृष्ठ) चुनें</p>
                </div>
              </div>
              <PdfUpload
                extractedText={pdfText}
                filename={pdfFilename}
                pageCount={pageCount}
                onTextExtracted={(text, name, pc) => {
                  setPdfText(text);
                  setPdfFilename(name);
                  setPageCount(pc);
                }}
              />
            </section>

            {/* Section 2: Client Info + Past Events */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-lg bg-rose-100 flex items-center justify-center">
                  <CalendarHeart className="w-5 h-5 text-rose-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">2. ग्राहक विवरण एवं पूर्व घटनाएँ</h3>
                  <p className="text-slate-400 text-xs">विवाह, शिक्षा, संतान आदि की जानकारी दें</p>
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  ग्राहक नाम
                </label>
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="ग्राहक का पूरा नाम"
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
                />
              </div>

              <PastEventsForm events={pastEvents} onChange={setPastEvents} />

              <div className="mt-5 pt-5 border-t border-slate-100">
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  मुख्य प्रश्न
                </label>
                <textarea
                  value={mainQuestion}
                  onChange={(e) => setMainQuestion(e.target.value)}
                  placeholder="जैसे: मेरी संतान कब होगी? नौकरी में पदोन्नति के योग? विवाह कब होगा?"
                  rows={3}
                  className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all resize-none"
                />
              </div>
            </section>

            {/* Section 3: API Key + Generate */}
            <section className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 rounded-lg bg-violet-100 flex items-center justify-center">
                  <KeyRound className="w-5 h-5 text-violet-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 text-base">3. AI विश्लेषण जनरेट करें</h3>
                  <p className="text-slate-400 text-xs">Gemini API कुंजी दर्ज करें और रिपोर्ट बनाएँ</p>
                </div>
              </div>

              <div className="mb-5">
                <ApiKeyInput apiKey={apiKey} onChange={setApiKey} />
              </div>

              <div className="bg-slate-50 rounded-lg p-4 mb-5 border border-slate-100">
                <div className="flex items-start gap-2.5">
                  <HelpCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <div className="text-xs text-slate-500 space-y-1">
                    <p>
                      <span className="font-medium text-slate-700">आवश्यक:</span> कुंडली PDF अपलोड किया गया हो और Gemini API कुंजी दर्ज हो।
                    </p>
                    <p>
                      <span className="font-medium text-slate-700">रिपोर्ट:</span> दो चरणों में — (1) डेटा निष्कर्षण एवं अखंडता जाँच (दशा, ग्रह, अष्टकवर्ग, वर्ग कुंडली, पूर्व घटना सत्यापन), (2) सटीक ज्योतिषीय-वास्तु रिपोर्ट (6 भाग)।
                    </p>
                  </div>
                </div>
              </div>

              {!canGenerate && (pdfText.length < 50 || apiKey.length < 10) && (
                <div className="mb-4 flex items-center gap-2 text-xs text-slate-400">
                  {!pdfText.trim() && (
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-slate-300" /> PDF अपलोड लंबित
                    </span>
                  )}
                  {pdfText.trim() && apiKey.length < 10 && (
                    <span className="flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-slate-300" /> API कुंजी आवश्यक
                    </span>
                  )}
                </div>
              )}

              <GenerateButton
                onGenerate={handleGenerate}
                loading={loading}
                disabled={!canGenerate}
                hasReport={!!report}
                onReset={handleReset}
              />
            </section>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="max-w-2xl mx-auto no-print">
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8">
                <div className="flex flex-col items-center gap-4">
                  <div className="relative w-20 h-20">
                    <div className="absolute inset-0 rounded-full border-4 border-amber-100" />
                    <Loader2 className="w-20 h-20 text-amber-500 animate-spin" />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Sparkles className="w-8 h-8 text-amber-500 animate-pulse" />
                    </div>
                  </div>
                  <div className="text-center">
                    <h3 className="text-slate-900 font-bold text-lg">
                      ज्योतिषीय विश्लेषण जारी है
                    </h3>
                    <p className="text-slate-400 text-sm mt-1 max-w-md">
                      ग्रहों की स्थिति, दशा-अंतर्दशा, और वास्तु का विस्तृत विश्लेषण तैयार हो रहा है...
                    </p>
                    <div className="mt-4 space-y-2 text-left max-w-xs mx-auto">
                      {["कुंडली डेटा निष्कर्षण", "पूर्व घटना सत्यापन", "ग्रहीय विश्लेषण", "वास्तु सलाह तैयार"].map(
                        (step, i) => (
                          <div key={step} className="flex items-center gap-2 text-xs">
                            <div
                              className={`w-4 h-4 rounded-full border-2 ${
                                i < 2
                                  ? "border-amber-500 bg-amber-500"
                                  : "border-slate-200"
                              } flex items-center justify-center`}
                            >
                              {i < 2 && (
                                <svg className="w-2.5 h-2.5 text-white" viewBox="0 0 12 12" fill="none">
                                  <path
                                    d="M2 6L5 9L10 3"
                                    stroke="currentColor"
                                    strokeWidth="2"
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                </svg>
                              )}
                            </div>
                            <span className={i < 2 ? "text-slate-700" : "text-slate-400"}>
                              {step}
                            </span>
                          </div>
                        )
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Report Output */}
          {report && !loading && (
            <div className="space-y-6">
              <ReportRenderer markdown={report} />
              <div className="flex gap-3 no-print">
                <button
                  onClick={() => window.print()}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 transition-all"
                >
                  <FileText className="w-4 h-4" />
                  प्रिंट / PDF सेव करें
                </button>
                <button
                  onClick={handleReset}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50 transition-all"
                >
                  नया विश्लेषण शुरू करें
                </button>
              </div>
            </div>
          )}
        </main>

        <footer className="border-t border-slate-200 py-6 px-6 text-center no-print">
          <p className="text-slate-400 text-xs">
            ज्योतिष AI विश्लेषण · शैक्षणिक उद्देश्य हेतु · परामर्श के लिए योग्य ज्योतिषी से संपर्क करें
          </p>
        </footer>
      </div>
    </div>
  );
}
