export interface PastEvents {
  marriageDate: string;
  education: string;
  childrenDobs: string;
  otherEvents: string;
}

export interface ReportRecord {
  id: string;
  client_name: string | null;
  pdf_filename: string | null;
  pdf_text: string | null;
  past_events: PastEvents | null;
  main_question: string | null;
  report_markdown: string | null;
  status: string;
  created_at: string;
}
