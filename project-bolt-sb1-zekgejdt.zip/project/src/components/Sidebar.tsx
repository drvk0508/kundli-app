import { Sparkles, FileText, Zap, BookOpen, Home, Star } from "lucide-react";

export default function Sidebar() {
  const navItems = [
    { icon: Home, label: "डैशबोर्ड", active: true },
    { icon: FileText, label: "रिपोर्ट्स", active: false },
    { icon: BookOpen, label: "ज्योतिष ग्रंथ", active: false },
    { icon: Star, label: "राशिफल", active: false },
  ];

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-gradient-to-b from-slate-900 to-slate-950 border-r border-slate-800 min-h-screen sticky top-0">
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg shadow-amber-500/20">
            <Sparkles className="w-6 h-6 text-slate-900" />
          </div>
          <div>
            <h1 className="text-white font-bold text-lg leading-tight">Acharya Vijay Krishna Shastri</h1>
            <p className="text-amber-400/80 text-xs">Acharya Vijay Krishna Shastri</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.label}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
              item.active
                ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                : "text-slate-400 hover:text-white hover:bg-slate-800/50"
            }`}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span className="text-amber-400 text-xs font-semibold">AI संस्करण</span>
          </div>
          <p className="text-slate-500 text-xs">Gemini 2.5 Flash द्वारा संचालित</p>
        </div>
      </div>
    </aside>
  );
}
