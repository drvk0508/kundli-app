import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ScrollText, CheckCircle2 } from "lucide-react";

interface Props {
  markdown: string;
}

export default function ReportRenderer({ markdown }: Props) {
  if (!markdown.trim()) return null;

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 px-6 py-4 flex items-center gap-3">
        <ScrollText className="w-6 h-6 text-amber-400" />
        <div>
          <h2 className="text-white font-bold text-lg">महा-ज्योतिष विश्लेषण रिपोर्ट</h2>
          <p className="text-amber-400/70 text-xs">आचार्य विजय कृष्ण शास्त्री पद्धति · देवनागरी हिंदी</p>
        </div>
        <div className="ml-auto flex items-center gap-2 bg-green-500/10 border border-green-500/20 px-3 py-1.5 rounded-lg">
          <CheckCircle2 className="w-4 h-4 text-green-400" />
          <span className="text-green-400 text-xs font-medium">पूर्ण</span>
        </div>
      </div>

      <div className="p-6 md:p-8">
        <div className="prose-astrology max-w-none">
          <ReactMarkdown remarkPlugins={[remarkGfm]} components={markdownComponents}>
            {markdown}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
}

const markdownComponents: Components = {
  h2: ({ children }) => (
    <h2 className="text-2xl font-bold text-slate-900 mt-8 mb-4 pb-2 border-b-2 border-amber-500/30 flex items-center gap-2">
      <span className="w-1.5 h-6 rounded-full bg-amber-500" />
      {children}
    </h2>
  ),
  h3: ({ children }) => (
    <h3 className="text-xl font-bold text-amber-700 mt-6 mb-3">{children}</h3>
  ),
  h4: ({ children }) => (
    <h4 className="text-lg font-semibold text-slate-800 mt-4 mb-2">{children}</h4>
  ),
  p: ({ children }) => (
    <p className="text-slate-700 leading-relaxed mb-4 text-[15px]">{children}</p>
  ),
  ul: ({ children }) => (
    <ul className="space-y-1.5 mb-4 ml-1">{children}</ul>
  ),
  ol: ({ children }) => (
    <ol className="space-y-1.5 mb-4 ml-1 list-decimal list-inside">{children}</ol>
  ),
  li: ({ children }) => (
    <li className="text-slate-700 text-[15px] leading-relaxed flex gap-2">
      <span className="text-amber-500 mt-1 flex-shrink-0">◆</span>
      <span>{children}</span>
    </li>
  ),
  strong: ({ children }) => (
    <strong className="font-bold text-slate-900">{children}</strong>
  ),
  em: ({ children }) => (
    <em className="italic text-slate-600">{children}</em>
  ),
  table: ({ children }) => (
    <div className="overflow-x-auto mb-6 my-4 rounded-xl border border-slate-200 shadow-sm">
      <table className="w-full text-sm border-collapse">{children}</table>
    </div>
  ),
  thead: ({ children }) => (
    <thead className="bg-gradient-to-r from-slate-800 to-slate-900">{children}</thead>
  ),
  th: ({ children }) => (
    <th className="px-4 py-3 text-left font-semibold text-amber-400 border-b border-slate-700 whitespace-nowrap">
      {children}
    </th>
  ),
  td: ({ children }) => (
    <td className="px-4 py-3 text-slate-700 border-b border-slate-100 border-r border-slate-100 last:border-r-0">
      {children}
    </td>
  ),
  tr: ({ children }) => (
    <tr className="hover:bg-amber-50/40 transition-colors even:bg-slate-50/50">
      {children}
    </tr>
  ),
  hr: () => <hr className="border-slate-200 my-6" />,
  blockquote: ({ children }) => (
    <blockquote className="border-l-4 border-amber-400 bg-amber-50/50 pl-4 pr-3 py-3 rounded-r-lg my-4 italic text-slate-700">
      {children}
    </blockquote>
  ),
  code: ({ children }) => (
    <code className="bg-slate-100 text-amber-700 px-1.5 py-0.5 rounded text-sm font-mono">
      {children}
    </code>
  ),
};

import type { Components } from "react-markdown";
