import { Sparkles, Loader2, FileDown, RotateCcw } from "lucide-react";

interface Props {
  onGenerate: () => void;
  loading: boolean;
  disabled: boolean;
  hasReport: boolean;
  onReset: () => void;
}

export default function GenerateButton({
  onGenerate,
  loading,
  disabled,
  hasReport,
  onReset,
}: Props) {
  if (loading) {
    return (
      <div className="flex flex-col items-center gap-4 py-8">
        <div className="relative">
          <div className="w-16 h-16 rounded-full border-4 border-amber-200" />
          <Loader2 className="w-16 h-16 text-amber-500 animate-spin absolute inset-0" />
        </div>
        <div className="text-center">
          <p className="text-slate-800 font-semibold text-base">रिपोर्ट जनरेट हो रही है...</p>
          <p className="text-slate-400 text-sm mt-1">
            ज्योतिषीय विश्लेषण तैयार होने में कुछ क्षण लगेंगे
          </p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <Sparkles className="w-4 h-4 text-amber-500 animate-pulse" />
            <span className="text-amber-600 text-xs font-medium">AI विश्लेषण प्रगति पर</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <button
        onClick={onGenerate}
        disabled={disabled}
        className={`w-full flex items-center justify-center gap-2.5 px-6 py-4 rounded-xl font-semibold text-base transition-all ${
          disabled
            ? "bg-slate-100 text-slate-400 cursor-not-allowed"
            : "bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-500/30 hover:shadow-xl hover:shadow-amber-500/40 hover:-translate-y-0.5 active:translate-y-0"
        }`}
      >
        <Sparkles className="w-5 h-5" />
        {hasReport ? "रिपोर्ट पुनः जनरेट करें" : "विस्तृत रिपोर्ट जनरेट करें"}
      </button>

      {hasReport && (
        <div className="flex gap-3">
          <button
            onClick={() => window.print()}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-all"
          >
            <FileDown className="w-4 h-4" />
            प्रिंट / PDF
          </button>
          <button
            onClick={onReset}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            नया विश्लेषण
          </button>
        </div>
      )}
    </div>
  );
}
