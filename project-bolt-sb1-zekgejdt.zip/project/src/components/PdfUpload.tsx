import { useRef, useState } from "react";
import { Upload, FileText, Loader2, CheckCircle2, X, AlertCircle } from "lucide-react";
import { extractPdfText } from "@/lib/pdfExtractor";

interface Props {
  onTextExtracted: (text: string, filename: string, pageCount: number) => void;
  extractedText: string;
  filename: string;
  pageCount: number;
}

export default function PdfUpload({ onTextExtracted, extractedText, filename, pageCount }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);

  const handleFile = async (file: File) => {
    if (file.type !== "application/pdf" && !file.name.endsWith(".pdf")) {
      setError("कृपया केवल PDF फ़ाइल अपलोड करें");
      return;
    }
    setError(null);
    setLoading(true);
    try {
      const { text, pageCount: pc } = await extractPdfText(file);
      onTextExtracted(text, file.name, pc);
    } catch (err) {
      const message = err instanceof Error ? err.message : "PDF पार्स विफल";
      setError(`PDF निष्कर्षण त्रुटि: ${message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  return (
    <div>
      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
      />

      {!extractedText && !loading && (
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all ${
            dragOver
              ? "border-amber-500 bg-amber-500/5 scale-[1.01]"
              : "border-slate-300 hover:border-amber-400 hover:bg-amber-50/50"
          }`}
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-100 to-amber-200 flex items-center justify-center mx-auto mb-4">
            <Upload className="w-8 h-8 text-amber-600" />
          </div>
          <p className="text-slate-700 font-semibold text-base mb-1">
            AstroSage कुंडली PDF अपलोड करें
          </p>
          <p className="text-slate-400 text-sm">
            ड्रैग और ड्रॉप करें या क्लिक करें · ~56 पृष्ठ
          </p>
        </div>
      )}

      {loading && (
        <div className="border-2 border-amber-500/30 rounded-xl p-8 text-center bg-amber-50/50">
          <Loader2 className="w-10 h-10 text-amber-500 animate-spin mx-auto mb-3" />
          <p className="text-slate-700 font-medium">PDF पाठ निष्कर्षित किया जा रहा है...</p>
          <p className="text-slate-400 text-sm mt-1">कृपया प्रतीक्षा करें</p>
        </div>
      )}

      {error && (
        <div className="border-2 border-red-200 rounded-xl p-4 bg-red-50 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-red-700 text-sm">{error}</p>
          <button
            onClick={() => setError(null)}
            className="ml-auto text-red-400 hover:text-red-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {extractedText && !loading && (
        <div className="border-2 border-green-200 rounded-xl p-5 bg-green-50/50">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-green-500 flex items-center justify-center">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-slate-800 font-semibold text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-green-600" />
                {filename}
              </p>
              <p className="text-green-600 text-xs mt-0.5">
                {pageCount} पृष्ठ · {extractedText.length.toLocaleString()} अक्षर निष्कर्षित
              </p>
            </div>
            <button
              onClick={() => {
                onTextExtracted("", "", 0);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }}
              className="text-slate-400 hover:text-red-500 transition-colors p-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="bg-white rounded-lg border border-green-100 p-3 max-h-32 overflow-y-auto">
            <pre className="text-xs text-slate-500 whitespace-pre-wrap font-mono">
              {extractedText.substring(0, 500)}...
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
