import { useState } from "react";
import { Eye, EyeOff, Key, HelpCircle } from "lucide-react";

interface Props {
  apiKey: string;
  onChange: (key: string) => void;
}

export default function ApiKeyInput({ apiKey, onChange }: Props) {
  const [show, setShow] = useState(false);

  return (
    <div>
      <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
        <Key className="w-4 h-4 text-amber-600" />
        Google Gemini API कुंजी
      </label>
      <div className="relative">
        <input
          type={show ? "text" : "password"}
          value={apiKey}
          onChange={(e) => onChange(e.target.value)}
          placeholder="AIza..."
          className="w-full px-4 py-2.5 pr-11 rounded-lg border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all font-mono"
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
        >
          {show ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
        </button>
      </div>
      <a
        href="https://aistudio.google.com/apikey"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-1.5 mt-2 text-xs text-amber-600 hover:text-amber-700 transition-colors"
      >
        <HelpCircle className="w-3.5 h-3.5" />
        API कुंजी कैसे प्राप्त करें?
      </a>
    </div>
  );
}
