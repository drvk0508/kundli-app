import { Calendar, GraduationCap, Baby, FileQuestion } from "lucide-react";
import type { PastEvents } from "@/lib/types";

interface Props {
  events: PastEvents;
  onChange: (events: PastEvents) => void;
}

export default function PastEventsForm({ events, onChange }: Props) {
  const fields: {
    key: keyof PastEvents;
    label: string;
    icon: typeof Calendar;
    placeholder: string;
    type?: string;
  }[] = [
    {
      key: "marriageDate",
      label: "विवाह तिथि",
      icon: Calendar,
      placeholder: "दिनांक चुनें",
      type: "date",
    },
    {
      key: "education",
      label: "शिक्षा विवरण",
      icon: GraduationCap,
      placeholder: "जैसे: B.Tech, 2015 में पूर्ण",
    },
    {
      key: "childrenDobs",
      label: "संतान जन्म तिथि",
      icon: Baby,
      placeholder: "जैसे: पुत्र - 15/08/2020, पुत्री - 22/03/2023",
    },
    {
      key: "otherEvents",
      label: "अन्य महत्वपूर्ण घटनाएँ",
      icon: FileQuestion,
      placeholder: "जैसे: नौकरी आरंभ, स्थान परिवर्तन, आदि",
    },
  ];

  return (
    <div className="space-y-4">
      {fields.map((field) => (
        <div key={field.key}>
          <label className="flex items-center gap-2 text-sm font-medium text-slate-700 mb-1.5">
            <field.icon className="w-4 h-4 text-amber-600" />
            {field.label}
          </label>
          {field.key === "otherEvents" ? (
            <textarea
              value={events[field.key]}
              onChange={(e) => onChange({ ...events, [field.key]: e.target.value })}
              placeholder={field.placeholder}
              rows={3}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all resize-none"
            />
          ) : (
            <input
              type={field.type || "text"}
              value={events[field.key]}
              onChange={(e) => onChange({ ...events, [field.key]: e.target.value })}
              placeholder={field.placeholder}
              className="w-full px-4 py-2.5 rounded-lg border border-slate-200 text-sm text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:border-transparent transition-all"
            />
          )}
        </div>
      ))}
    </div>
  );
}
